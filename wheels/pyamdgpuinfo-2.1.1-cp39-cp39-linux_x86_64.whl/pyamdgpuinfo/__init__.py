# from .pyamdgpuinfo import (setup_gpus, start_utilisation_polling, stop_utilisation_polling, cleanup,
#                            query_max_clocks, query_vram_usage, query_gtt_usage, query_sclk,
#                            query_mclk, query_temp, query_load, query_power, query_utilisation)
from .pyamdgpuinfo import (GPUInfo, get_gpu, detect_gpus)
